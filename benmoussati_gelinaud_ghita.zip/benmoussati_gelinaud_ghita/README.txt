 --- To launch the game ---

- Install Java : 

https://www.java.com/fr/download/

- Install Java SE

https://www.oracle.com/java/technologies/java-se-glance.html

- Open a command terminal in the directory project/src/main/java.

- Run the command "javac squid/Start.java".

- Run the command "java squid/Start"

- Have fun.

 --- To play ---

- The game works only with command lines.

- First, you'll have to choose a username.

- Type "help" to display available commands.

- The goal of the game is to finish the 6 mini-games and be the last man standing.